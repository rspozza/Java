import Pyro4
import sys

calculadora = Pyro4.Proxy("PYRONAME:calculadora")

try:
    calculadora._pyroBind()
except Pyro4.errors.CommunicationError:
    print("Objeto remoto não encontrado. Encerrando execução")
    sys.exit(1)


opcao = 0

while (opcao != 5):
    print("Digite:\n")
    print("1 - Somar dois numeros")
    print("2 - Subtrair dois numeros")
    print("3 - Dividir dois numeros")
    print("4 - Multiplicar dois numeros")
    print("5 - Sair\n")

    opcao = int(input('Opção: '))

    if(opcao >= 1 and opcao <= 4):
        operando1 = int(input("Digite primeiro operando: "))
        operando2 = int(input("Digite segundo operando: "))

    if(opcao == 1):
        print("Resultado da soma:", calculadora.soma(operando1, operando2))
    elif(opcao == 2):
        print("Resultado da subtração:", calculadora.subtracao(operando1, operando2))
    elif(opcao == 3):
        print("Resultado da divisão:", calculadora.divisao(operando1, operando2))
    elif(opcao == 4):
        print("Resultado da multiplicação:", calculadora.multiplicacao(operando1, operando2))
    elif(opcao == 5):
        print("Saindo...")
    else:
        print("Operação inválida")