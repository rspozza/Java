import Pyro4

@Pyro4.expose
class Calculadora(object):
    def soma(self, operando1, operando2):
        return operando1 + operando2

    def subtracao(self, operando1, operando2):
        return operando1 - operando2

    def divisao(self, operando1, operando2):
        return operando1/operando2

    def multiplicacao(self, operando1, operando2):
        return operando1*operando2

def main():

    daemon = Pyro4.Daemon()
    uri = daemon.register(Calculadora)
    print("Objeto servidor publicado.")

    ns = Pyro4.locateNS()
    ns.register("calculadora", uri)
    print("Objeto registrado no serviço de nome.")

    daemon.requestLoop()

if __name__ == "__main__": main()
